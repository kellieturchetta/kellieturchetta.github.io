package com.example.module5;

public class contact {
    int id;
    String Username, Password;

    public void setId(int id)
    {
        this.id = id;
    }
    public int getId(){
        return this.id;
    }
    public void setUsername (String Username)
    {
        this.Username = Username;
    }
    public String getUsername()
    {
        return this.Username;
    }

    public void setPassword (String Password)
    {
        this.Password = Password;
    }
    public String getPassword()
    {
        return this.Password;
    }
}

