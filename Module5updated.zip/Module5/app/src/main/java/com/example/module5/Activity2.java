package com.example.module5;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Toast;

import static com.example.module5.R.*;


public class Activity2 extends AppCompatActivity {
    private Button button;
    DatabaseHelper myDb;
    EditText editWeight, editCalories, editDate;
    Button btnAddData;
    Button btnViewAll;
    Button btnDelete;
    Button btnViewUpdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_2);
        myDb = new DatabaseHelper(this);

        editWeight = (EditText) findViewById(id.EditText38);
        editCalories = (EditText) findViewById(id.EditText41);
        editDate = (EditText) findViewById(id.EditTextdate);
        btnAddData = (Button) findViewById(id.button30);
        btnViewAll = (Button) findViewById(id.button50);
        btnViewUpdate = (Button) findViewById(id.button300);
        btnDelete = (Button) findViewById(id.button31);

        AddData();
        ViewAll();
        UpdateData();
        DeleteData();


        //SMS Manager Button
        button = (Button) findViewById(id.button29);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity3();
            }
        });

        //Logs user out
        button = (Button) findViewById(id.button70);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });

    }

    //Takes user to the SMS page
    public void openActivity3() {
        Intent intent = new Intent(this, Activity3.class);
        startActivity(intent);
    }

    //Takes the user to the Log-in screen
    public void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    //Deletes Data
    public void DeleteData() {
        btnDelete.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer deletedRows = myDb.deleteData(editDate.getText().toString());
                        if (deletedRows > 0)
                            Toast.makeText(Activity2.this, "Data Deleted", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(Activity2.this, "Data not Deleted", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    //Updates Data
    public void UpdateData() {
        btnViewUpdate.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isUpdate = myDb.updateData(editWeight.getText().toString(),
                                editCalories.getText().toString(),
                                editDate.getText().toString());
                        if (isUpdate == true)
                            Toast.makeText(Activity2.this, "Data Update", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(Activity2.this, "Data not Updated", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

//Adds Data
    public void AddData() {
        btnAddData.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDb.insertData(editWeight.getText().toString(),
                                editCalories.getText().toString(),
                                editDate.getText().toString());
                        if (isInserted == true)
                            Toast.makeText(Activity2.this, "Data Inserted", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(Activity2.this, "Data not Inserted", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    //View Data
    public void ViewAll() {
        btnViewAll.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDb.getAllData();
                        if (res.getCount() == 0) {
                            // show message
                            showMessage("Error", "Nothing found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("Weight :" + res.getString(1) + "\n");
                            buffer.append("Calories :" + res.getString(2) + "\n");
                            buffer.append("Date :" + res.getString(3) + "\n");

                        }

                        // Show all data
                        showMessage("Data", buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title, String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
}







